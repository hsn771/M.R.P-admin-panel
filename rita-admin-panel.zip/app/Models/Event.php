<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Event extends Model
{
    protected $fillable = [
        'title',
        'date',
        'description',
    ];

    protected $casts = [
        'date' => 'date',
    ];
}
