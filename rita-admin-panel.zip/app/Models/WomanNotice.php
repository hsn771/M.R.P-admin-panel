<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class WomanNotice extends Model
{
    protected $fillable = [
        'title',
        'description',
        'date',
    ];

    protected $casts = [
        'date' => 'date',
    ];
}
