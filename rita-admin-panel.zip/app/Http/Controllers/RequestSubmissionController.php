<?php

namespace App\Http\Controllers;

use App\Models\RequestSubmission;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class RequestSubmissionController extends Controller
{
    public function store(Request $request): JsonResponse
    {
        $data = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'subject' => ['required', 'string', 'max:255'],
            'address' => ['required', 'string'],
            'email' => ['nullable', 'email', 'max:255'],
            'mobile_number' => ['required', 'string', 'max:20'],
            'voter_id_card_number' => ['required', 'string', 'max:50'],
            'detailed_description' => ['required', 'string'],
        ]);

        $submission = RequestSubmission::create($data);

        return response()->json([
            'success' => true,
            'message' => 'আপনার অনুরোধ সফলভাবে জমা দেওয়া হয়েছে।',
            'data' => $submission,
        ], 201);
    }
}
