<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Setting;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\View\View;

class HeaderLogoController extends Controller
{
    public function index(): View
    {
        $setting = Setting::first();

        return view('admin.header-logos.index', compact('setting'));
    }

    public function edit(): View
    {
        $setting = Setting::first();

        return view('admin.header-logos.edit', compact('setting'));
    }

    public function update(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'name_eng' => ['required', 'string', 'max:255'],
            'name_bn' => ['required', 'string', 'max:255'],
            'email' => ['required', 'email', 'max:255'],
            'phone' => ['required', 'string', 'max:255'],
            'address' => ['required', 'string'],
            'facebook' => ['nullable', 'string', 'max:255'],
            'twitter' => ['nullable', 'string', 'max:255'],
            'instagram' => ['nullable', 'string', 'max:255'],
            'linkedin' => ['nullable', 'string', 'max:255'],
            'youtube' => ['nullable', 'string', 'max:255'],
            'logo_footer' => ['nullable', 'image', 'mimes:jpeg,png,jpg,gif,webp,svg', 'max:2048'],
            'logo_header' => ['nullable', 'image', 'mimes:jpeg,png,jpg,gif,webp,svg', 'max:2048'],
            'contact_page_title' => ['required', 'string', 'max:255'],
            'contact_page_description' => ['required', 'string'],
            'contact_page_subtitle' => ['required', 'string', 'max:255'],
            'footer_description' => ['nullable', 'string'],
        ]);

        $setting = Setting::first();

        // Handle logo_footer upload
        if ($request->hasFile('logo_footer')) {
            // Delete old logo if exists
            if ($setting && $setting->logo_footer && Storage::disk('public')->exists($setting->logo_footer)) {
                Storage::disk('public')->delete($setting->logo_footer);
            }
            $logoPath = $request->file('logo_footer')->store('settings', 'public');
            $data['logo_footer'] = $logoPath;
        } else {
            unset($data['logo_footer']);
        }

        // Handle logo_header upload
        if ($request->hasFile('logo_header')) {
            // Delete old logo if exists
            if ($setting && $setting->logo_header && Storage::disk('public')->exists($setting->logo_header)) {
                Storage::disk('public')->delete($setting->logo_header);
            }
            $logoPath = $request->file('logo_header')->store('settings', 'public');
            $data['logo_header'] = $logoPath;
        } else {
            unset($data['logo_header']);
        }

        if ($setting) {
            $setting->update($data);
        } else {
            Setting::create($data);
        }

        return redirect()
            ->route('admin.header-logos.index')
            ->with('status', 'Settings updated successfully.');
    }
}
