<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\HeroSection;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\View\View;

class HeroSectionController extends Controller
{
    public function index(): View
    {
        $heroSections = HeroSection::orderBy('created_at', 'desc')->paginate(15);

        return view('admin.hero-sections.index', compact('heroSections'));
    }

    public function create(): View
    {
        return view('admin.hero-sections.create');
    }

    public function store(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'image' => ['required', 'image', 'mimes:jpeg,png,jpg,gif,webp', 'max:2048'],
            'description' => ['required', 'string'],
        ]);

        if ($request->hasFile('image')) {
            $imagePath = $request->file('image')->store('hero-sections', 'public');
            $data['image'] = $imagePath;
        }

        HeroSection::create($data);

        return redirect()
            ->route('admin.hero-sections.index')
            ->with('status', 'Hero section created successfully.');
    }

    public function edit(HeroSection $heroSection): View
    {
        return view('admin.hero-sections.edit', compact('heroSection'));
    }

    public function update(Request $request, HeroSection $heroSection): RedirectResponse
    {
        $data = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'image' => ['nullable', 'image', 'mimes:jpeg,png,jpg,gif,webp', 'max:2048'],
            'description' => ['required', 'string'],
        ]);

        if ($request->hasFile('image')) {
            // Delete old image
            if ($heroSection->image && Storage::disk('public')->exists($heroSection->image)) {
                Storage::disk('public')->delete($heroSection->image);
            }
            $imagePath = $request->file('image')->store('hero-sections', 'public');
            $data['image'] = $imagePath;
        } else {
            unset($data['image']);
        }

        $heroSection->update($data);

        return redirect()
            ->route('admin.hero-sections.index')
            ->with('status', 'Hero section updated successfully.');
    }

    public function destroy(HeroSection $heroSection): RedirectResponse
    {
        // Delete image file
        if ($heroSection->image && Storage::disk('public')->exists($heroSection->image)) {
            Storage::disk('public')->delete($heroSection->image);
        }

        $heroSection->delete();

        return redirect()
            ->route('admin.hero-sections.index')
            ->with('status', 'Hero section deleted successfully.');
    }
}
