<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\VideoGallery;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\View\View;

class VideoGalleryController extends Controller
{
    public function index(): View
    {
        $videoGalleries = VideoGallery::orderBy('created_at', 'desc')->paginate(15);

        return view('admin.video-galleries.index', compact('videoGalleries'));
    }

    public function create(): View
    {
        return view('admin.video-galleries.create');
    }

    public function store(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'video' => ['required', 'mimes:mp4,mov,avi,wmv,flv,webm', 'max:102400'], // 10MB max
        ]);

        if ($request->hasFile('video')) {
            $videoPath = $request->file('video')->store('video-galleries', 'public');
            $data['video'] = $videoPath;
        }

        VideoGallery::create($data);

        return redirect()
            ->route('admin.video-galleries.index')
            ->with('status', 'Video added to gallery successfully.');
    }

    public function edit(VideoGallery $videoGallery): View
    {
        return view('admin.video-galleries.edit', compact('videoGallery'));
    }

    public function update(Request $request, VideoGallery $videoGallery): RedirectResponse
    {
        $data = $request->validate([
            'video' => ['nullable', 'mimes:mp4,mov,avi,wmv,flv,webm', 'max:102400'],
        ]);

        if ($request->hasFile('video')) {
            // Delete old video
            if ($videoGallery->video && Storage::disk('public')->exists($videoGallery->video)) {
                Storage::disk('public')->delete($videoGallery->video);
            }
            $videoPath = $request->file('video')->store('video-galleries', 'public');
            $data['video'] = $videoPath;
        } else {
            unset($data['video']);
        }

        $videoGallery->update($data);

        return redirect()
            ->route('admin.video-galleries.index')
            ->with('status', 'Video updated successfully.');
    }

    public function destroy(VideoGallery $videoGallery): RedirectResponse
    {
        // Delete video file
        if ($videoGallery->video && Storage::disk('public')->exists($videoGallery->video)) {
            Storage::disk('public')->delete($videoGallery->video);
        }

        $videoGallery->delete();

        return redirect()
            ->route('admin.video-galleries.index')
            ->with('status', 'Video deleted successfully.');
    }
}
