<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\PhotoGallery;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\View\View;

class PhotoGalleryController extends Controller
{
    public function index(): View
    {
        $photoGalleries = PhotoGallery::orderBy('created_at', 'desc')->paginate(15);

        return view('admin.photo-galleries.index', compact('photoGalleries'));
    }

    public function create(): View
    {
        return view('admin.photo-galleries.create');
    }

    public function store(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'image' => ['required', 'image', 'mimes:jpeg,png,jpg,gif,webp', 'max:2048'],
        ]);

        if ($request->hasFile('image')) {
            $imagePath = $request->file('image')->store('photo-galleries', 'public');
            $data['image'] = $imagePath;
        }

        PhotoGallery::create($data);

        return redirect()
            ->route('admin.photo-galleries.index')
            ->with('status', 'Photo added to gallery successfully.');
    }

    public function edit(PhotoGallery $photoGallery): View
    {
        return view('admin.photo-galleries.edit', compact('photoGallery'));
    }

    public function update(Request $request, PhotoGallery $photoGallery): RedirectResponse
    {
        $data = $request->validate([
            'image' => ['nullable', 'image', 'mimes:jpeg,png,jpg,gif,webp', 'max:2048'],
        ]);

        if ($request->hasFile('image')) {
            // Delete old image
            if ($photoGallery->image && Storage::disk('public')->exists($photoGallery->image)) {
                Storage::disk('public')->delete($photoGallery->image);
            }
            $imagePath = $request->file('image')->store('photo-galleries', 'public');
            $data['image'] = $imagePath;
        } else {
            unset($data['image']);
        }

        $photoGallery->update($data);

        return redirect()
            ->route('admin.photo-galleries.index')
            ->with('status', 'Photo updated successfully.');
    }

    public function destroy(PhotoGallery $photoGallery): RedirectResponse
    {
        // Delete image file
        if ($photoGallery->image && Storage::disk('public')->exists($photoGallery->image)) {
            Storage::disk('public')->delete($photoGallery->image);
        }

        $photoGallery->delete();

        return redirect()
            ->route('admin.photo-galleries.index')
            ->with('status', 'Photo deleted successfully.');
    }
}
